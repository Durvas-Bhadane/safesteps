# 🛡️ SafeSteps – Pre-Teen Learning Portal

A production-grade React frontend for a safe, fun, and trusted learning platform built for children aged 10–13.

---

## 🚀 Quick Start Commands

```bash
# 1. Navigate into the project folder
cd safesteps

# 2. Install all dependencies
npm install

# 3. Start the development server
npm start
```

The app will open at → **http://localhost:3000**

---

## 📦 Build for Production

```bash
npm run build
```

This creates an optimized production build in the `/build` folder.

---

## 🗂 Project Folder Structure

```
safesteps/
├── public/
│   └── index.html                  # HTML shell with Google Fonts
├── src/
│   ├── index.js                    # React entry point
│   ├── App.jsx                     # Root app + role-based routing
│   │
│   ├── data/
│   │   └── data.js                 # All dummy JSON data (articles, quizzes, badges)
│   │
│   ├── styles/
│   │   ├── theme.js                # Design tokens (colors, shadows, radii)
│   │   └── GlobalStyle.js          # Global CSS-in-JS styles + animations
│   │
│   ├── components/                 # Reusable components
│   │   ├── Logo.jsx                # SVG logo (Shield + Star + Checkmark)
│   │   ├── Navbar.jsx              # Top navigation bar
│   │   ├── Sidebar.jsx             # Left sidebar with role links
│   │   ├── Card.jsx                # Base card with hover animation
│   │   ├── StatCard.jsx            # Metric card (icon + value + label)
│   │   ├── CategoryCard.jsx        # Learning category card with progress
│   │   ├── BadgeCard.jsx           # Earned/locked badge display
│   │   ├── ProgressBar.jsx         # Animated progress bar
│   │   ├── ApprovalCard.jsx        # Admin article approval card
│   │   ├── FormInput.jsx           # Reusable form input/textarea
│   │   ├── SectionHeader.jsx       # Page section heading
│   │   ├── ArticleModal.jsx        # Article detail modal (Do's & Don'ts)
│   │   └── QuizModal.jsx           # Full quiz flow with scoring
│   │
│   └── pages/
│       ├── Landing.jsx             # Role selector home page
│       ├── kid/
│       │   ├── KidDashboard.jsx    # Kid layout + routing
│       │   ├── KidHome.jsx         # Welcome banner, stats, recent articles
│       │   ├── KidQuiz.jsx         # Quiz listing page
│       │   ├── KidBadges.jsx       # Badge collection page
│       │   └── KidProgress.jsx     # Progress tracker + streak calendar
│       ├── counselor/
│       │   └── CounselorDashboard.jsx  # Create article, my articles, guidelines
│       └── admin/
│           └── AdminDashboard.jsx  # Overview, pending, categories, users
│
├── package.json
└── README.md
```

---

## 🔐 Role-Based Access

| Role | Dashboard | Key Features |
|------|-----------|-------------|
| 🧒 **Kid** | `/kid/dashboard` | Learn, Quiz, Badges, Progress |
| 👩‍⚕️ **Counselor** | `/counselor/create` | Create Article, Preview, Submit |
| 🧑‍💼 **Admin** | `/admin/approval` | Approve/Reject, Manage Categories |

---

## 🔗 Future Backend Integration (Node.js + Express + MongoDB)

When you're ready to connect the backend:

### 1. Install React Router DOM (already in package.json)

Replace the state-based routing in `App.jsx` with:

```jsx
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';

// Wrap root in BrowserRouter inside index.js
<BrowserRouter>
  <Routes>
    <Route path="/"                 element={<Landing />} />
    <Route path="/kid/dashboard"    element={<PrivateRoute role="kid"><KidDashboard /></PrivateRoute>} />
    <Route path="/kid/quiz"         element={<PrivateRoute role="kid"><KidDashboard /></PrivateRoute>} />
    <Route path="/counselor/create" element={<PrivateRoute role="counselor"><CounselorDashboard /></PrivateRoute>} />
    <Route path="/admin/approval"   element={<PrivateRoute role="admin"><AdminDashboard /></PrivateRoute>} />
  </Routes>
</BrowserRouter>
```

### 2. Replace dummy data with API calls

```js
// Example: fetch articles from your Express API
const [articles, setArticles] = useState([]);

useEffect(() => {
  fetch('http://localhost:5000/api/articles', {
    headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
  })
    .then(res => res.json())
    .then(data => setArticles(data));
}, []);
```

### 3. JWT Auth flow

```js
// Login endpoint call
const login = async (email, password, role) => {
  const res = await fetch('http://localhost:5000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, role }),
  });
  const { token, user } = await res.json();
  localStorage.setItem('token', token);
  localStorage.setItem('role', user.role);
};
```

---

## 🎨 Tech Stack

| Layer | Technology |
|-------|-----------|
| UI Library | React 18 |
| Routing | React Router DOM v6 |
| Styling | CSS-in-JS (inline + global) |
| Animations | CSS keyframes + transitions |
| Fonts | Poppins + Nunito (Google Fonts) |
| Icons | Emoji-based (no extra library needed) |

---

## 📡 Recommended Backend Stack

```
Node.js + Express.js    → REST API
MongoDB + Mongoose      → Database
JWT                     → Authentication
bcrypt                  → Password hashing
multer                  → File uploads (future)
```

---

## 🌟 Features

- ✅ Role-based dashboards (Kid, Counselor, Admin)
- ✅ Interactive MCQ quiz with scoring & star rating
- ✅ Article modal with Do's & Don'ts
- ✅ Badge system (earned / locked)
- ✅ Progress tracker with streak calendar
- ✅ Counselor article creation with live preview
- ✅ Admin approval workflow
- ✅ Smooth page transitions & hover animations
- ✅ Custom SVG logo (Shield + Checkmark + Star)
- ✅ Fully responsive card-based layout
- ✅ Pastel color palette — fun but professional
