import React, { useState } from 'react';
import Navbar from '../../components/Navbar';
import Sidebar from '../../components/Sidebar';
import Card from '../../components/Card';
import StatCard from '../../components/StatCard';
import SectionHeader from '../../components/SectionHeader';
import ApprovalCard from '../../components/ApprovalCard';
import ProgressBar from '../../components/ProgressBar';
import { CATEGORIES, PENDING_ARTICLES } from '../../data/data';

const links = [
  { id: 'overview',   icon: '📊', label: 'Overview' },
  { id: 'pending',    icon: '⏳', label: 'Pending Reviews' },
  { id: 'categories', icon: '🗂',  label: 'Manage Categories' },
  { id: 'users',      icon: '👥', label: 'User Management' },
];

const activityFeed = [
  { icon: '📄', text: 'New article submitted by Dr. Priya Sharma',  time: '2 hours ago',  color: '#6C63FF', bg: '#EEF0FF' },
  { icon: '✅', text: "Article 'Cyberbullying' approved",           time: '5 hours ago',  color: '#00C9A7', bg: '#E6FDF8' },
  { icon: '👤', text: '15 new kid accounts registered today',       time: '1 day ago',    color: '#FFB84D', bg: '#FFF8EC' },
  { icon: '❌', text: 'Article rejected: insufficient content',     time: '2 days ago',   color: '#FF6B8B', bg: '#FFF0F3' },
];

const users = [
  { name: 'Aarav Kumar',      role: 'Kid',        joined: 'Jan 10', status: 'active' },
  { name: 'Dr. Priya Sharma', role: 'Counselor',  joined: 'Dec 5',  status: 'active' },
  { name: 'Siya Patel',       role: 'Kid',        joined: 'Jan 12', status: 'active' },
  { name: 'Dr. Arjun Mehta',  role: 'Counselor',  joined: 'Nov 20', status: 'active' },
  { name: 'Rohan Singh',      role: 'Kid',        joined: 'Jan 14', status: 'inactive' },
];

const AdminDashboard = () => {
  const [activePage, setActivePage]         = useState('overview');
  const [pendingList, setPendingList]       = useState(PENDING_ARTICLES);
  const [selectedArticle, setSelectedArticle] = useState(null);
  const [feedback, setFeedback]             = useState('');

  const approve = (id) => { setPendingList(l => l.filter(a => a.id !== id)); setSelectedArticle(null); };
  const reject  = (id) => { setPendingList(l => l.filter(a => a.id !== id)); setSelectedArticle(null); };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', background: '#F6F7FF' }}>
      <Navbar role="admin" />
      <div style={{ display: 'flex', flex: 1 }}>
        <Sidebar links={links} activePage={activePage} onNavigate={setActivePage} />
        <main style={{ flex: 1, padding: '28px 32px' }} className="page-enter">

          {/* ---- OVERVIEW ---- */}
          {activePage === 'overview' && (
            <div>
              <SectionHeader icon="📊" title="Admin Overview" subtitle="Platform health at a glance" />
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 16, marginBottom: 28 }}>
                <StatCard icon="📄" value="42"              label="Total Articles" color="#6C63FF" bg="#EEF0FF" />
                <StatCard icon="⏳" value={pendingList.length} label="Pending Review"  color="#FFB84D" bg="#FFF8EC" />
                <StatCard icon="👤" value="324"             label="Total Kids"     color="#00C9A7" bg="#E6FDF8" />
                <StatCard icon="👩‍⚕️" value="12"              label="Counselors"     color="#FF6B8B" bg="#FFF0F3" />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 24 }}>
                <Card style={{ padding: 24 }}>
                  <div style={{ fontWeight: 800, color: '#2D2D5E', marginBottom: 20, fontSize: 16 }}>📈 Recent Activity</div>
                  {activityFeed.map((a, i) => (
                    <div key={i} style={{
                      display: 'flex', alignItems: 'flex-start', gap: 14,
                      paddingBottom: 16, marginBottom: 16,
                      borderBottom: i < activityFeed.length - 1 ? '1px solid #f0efff' : 'none',
                    }}>
                      <div style={{
                        width: 36, height: 36, borderRadius: 10, background: a.bg,
                        display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0,
                      }}>
                        {a.icon}
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 14, fontWeight: 600, color: '#2D2D5E' }}>{a.text}</div>
                        <div style={{ fontSize: 12, color: '#7B7BA8', marginTop: 2 }}>{a.time}</div>
                      </div>
                    </div>
                  ))}
                </Card>

                <Card style={{ padding: 24 }}>
                  <div style={{ fontWeight: 800, color: '#2D2D5E', marginBottom: 20, fontSize: 16 }}>🗂 Category Usage</div>
                  {CATEGORIES.map((cat, i) => (
                    <div key={cat.id} style={{ marginBottom: 14 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                        <span style={{ fontSize: 13, fontWeight: 700, color: '#2D2D5E' }}>{cat.icon} {cat.title}</span>
                        <span style={{ fontSize: 12, color: '#7B7BA8' }}>{cat.articles}</span>
                      </div>
                      <ProgressBar value={30 + i * 10} color={cat.color} />
                    </div>
                  ))}
                </Card>
              </div>
            </div>
          )}

          {/* ---- PENDING REVIEWS ---- */}
          {activePage === 'pending' && (
            <div>
              <SectionHeader icon="⏳" title="Pending Reviews" subtitle={`${pendingList.length} articles awaiting approval`} />
              {pendingList.length === 0 ? (
                <Card style={{ textAlign: 'center', padding: 48 }}>
                  <div style={{ fontSize: 52, marginBottom: 16 }}>🎉</div>
                  <div style={{ fontWeight: 800, color: '#2D2D5E', fontSize: 18, marginBottom: 8 }}>All Clear!</div>
                  <div style={{ color: '#7B7BA8' }}>No articles pending review right now.</div>
                </Card>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                  {pendingList.map(art => (
                    <ApprovalCard key={art.id} article={art}
                      onApprove={approve} onReject={reject} onReview={setSelectedArticle} />
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ---- MANAGE CATEGORIES ---- */}
          {activePage === 'categories' && (
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
                <SectionHeader icon="🗂" title="Manage Categories" subtitle="Control learning topics" noMargin />
                <button className="btn btn-primary">+ Add Category</button>
              </div>
              <div style={{ background: 'white', borderRadius: 20, boxShadow: '0 4px 24px rgba(108,99,255,0.10)', overflow: 'hidden' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ background: '#f8f7ff' }}>
                      {['Icon', 'Category', 'Articles', 'Status', 'Actions'].map(h => (
                        <th key={h} style={{ padding: '14px 20px', textAlign: 'left', fontSize: 13, fontWeight: 700, color: '#7B7BA8' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {CATEGORIES.map(cat => (
                      <tr key={cat.id} className="table-row" style={{ borderTop: '1px solid #f0efff' }}>
                        <td style={{ padding: '14px 20px', fontSize: 24 }}>{cat.icon}</td>
                        <td style={{ padding: '14px 20px' }}>
                          <div style={{ fontWeight: 700, color: '#2D2D5E' }}>{cat.title}</div>
                          <div style={{ fontSize: 12, color: '#7B7BA8' }}>{cat.desc.substring(0, 40)}...</div>
                        </td>
                        <td style={{ padding: '14px 20px' }}>
                          <span className="chip" style={{ background: '#eef0ff', color: '#6C63FF' }}>{cat.articles}</span>
                        </td>
                        <td style={{ padding: '14px 20px' }}>
                          <span className="chip" style={{ background: '#e6fdf8', color: '#006654' }}>Active</span>
                        </td>
                        <td style={{ padding: '14px 20px' }}>
                          <div style={{ display: 'flex', gap: 8 }}>
                            <button className="btn btn-secondary btn-sm">Edit</button>
                            <button className="btn btn-danger btn-sm">Hide</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ---- USER MANAGEMENT ---- */}
          {activePage === 'users' && (
            <div>
              <SectionHeader icon="👥" title="User Management" subtitle="Manage all platform users" />
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 20, marginBottom: 24 }}>
                <StatCard icon="🧒" value="324" label="Kids"       color="#6C63FF" bg="#EEF0FF" />
                <StatCard icon="👩‍⚕️" value="12"  label="Counselors" color="#00C9A7" bg="#E6FDF8" />
                <StatCard icon="🧑‍💼" value="3"   label="Admins"     color="#5C6BC0" bg="#F0F1FF" />
              </div>
              <Card style={{ padding: 24 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
                  <div style={{ fontWeight: 800, fontSize: 16, color: '#2D2D5E' }}>Recent Users</div>
                  <input className="form-input" placeholder="Search users..." style={{ width: 220 }} />
                </div>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ background: '#f8f7ff' }}>
                      {['Name', 'Role', 'Joined', 'Status', 'Action'].map(h => (
                        <th key={h} style={{ padding: '12px 16px', textAlign: 'left', fontSize: 13, fontWeight: 700, color: '#7B7BA8' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((u, i) => (
                      <tr key={i} className="table-row" style={{ borderTop: '1px solid #f0efff' }}>
                        <td style={{ padding: '13px 16px', fontWeight: 700, color: '#2D2D5E' }}>{u.name}</td>
                        <td style={{ padding: '13px 16px' }}>
                          <span className="chip" style={{
                            background: u.role === 'Kid' ? '#eef0ff' : '#e6fdf8',
                            color:      u.role === 'Kid' ? '#6C63FF' : '#006654',
                          }}>
                            {u.role}
                          </span>
                        </td>
                        <td style={{ padding: '13px 16px', color: '#7B7BA8', fontSize: 13 }}>{u.joined}</td>
                        <td style={{ padding: '13px 16px' }}>
                          <span className="chip" style={{
                            background: u.status === 'active' ? '#e6fdf8' : '#f5f5f5',
                            color:      u.status === 'active' ? '#006654' : '#7B7BA8',
                          }}>
                            {u.status === 'active' ? '● Active' : '○ Inactive'}
                          </span>
                        </td>
                        <td style={{ padding: '13px 16px' }}>
                          <button className="btn btn-secondary btn-sm">View</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Card>
            </div>
          )}

        </main>
      </div>

      {/* Article Review Modal */}
      {selectedArticle && (
        <div className="modal-overlay" onClick={() => setSelectedArticle(null)}>
          <div className="modal-box" onClick={e => e.stopPropagation()}>
            <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 800, fontSize: 20, color: '#2D2D5E', marginBottom: 6 }}>
              {selectedArticle.title}
            </div>
            <div style={{ fontSize: 13, color: '#7B7BA8', marginBottom: 20 }}>
              By {selectedArticle.author} · {selectedArticle.category}
            </div>
            <div style={{ background: '#f8f7ff', borderRadius: 14, padding: 16, marginBottom: 20, color: '#7B7BA8', fontSize: 14, lineHeight: 1.7 }}>
              [Article content for review. In production, this fetches the full article from your MongoDB backend via the Express API.]
            </div>
            <div style={{ marginBottom: 16 }}>
              <label className="form-label">Feedback for Counselor (optional)</label>
              <textarea className="form-input" rows={3} placeholder="Add your feedback..."
                value={feedback} onChange={e => setFeedback(e.target.value)} />
            </div>
            <div style={{ display: 'flex', gap: 12 }}>
              <button className="btn btn-success" style={{ flex: 1, justifyContent: 'center' }} onClick={() => approve(selectedArticle.id)}>
                ✅ Approve Article
              </button>
              <button className="btn btn-danger" style={{ flex: 1, justifyContent: 'center' }} onClick={() => reject(selectedArticle.id)}>
                ❌ Reject Article
              </button>
              <button className="btn btn-secondary" onClick={() => setSelectedArticle(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
