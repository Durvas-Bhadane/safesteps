import React, { useState } from 'react';
import Navbar from '../../components/Navbar';
import Sidebar from '../../components/Sidebar';
import Card from '../../components/Card';
import SectionHeader from '../../components/SectionHeader';
import FormInput from '../../components/FormInput';
import { CATEGORIES } from '../../data/data';

const links = [
  { id: 'create',      icon: '✍️', label: 'Create Article' },
  { id: 'my-articles', icon: '📋', label: 'My Articles' },
  { id: 'guidelines',  icon: '📖', label: 'Guidelines' },
];

const statusColor = {
  pending:  { bg: '#fff8ec', color: '#b06000' },
  approved: { bg: '#e6fdf8', color: '#006654' },
  rejected: { bg: '#fff0f3', color: '#c0002a' },
};

const myArticles = [
  { id: 1, title: 'Understanding Peer Pressure', category: 'Healthy Relationships', status: 'pending',  date: 'Jan 15' },
  { id: 2, title: 'Screen Time & Mental Health',  category: 'Mental Wellness',       status: 'approved', date: 'Jan 10' },
  { id: 3, title: 'Building Self-Esteem',         category: 'Body Confidence',       status: 'rejected', date: 'Jan 5'  },
];

const guidelineItems = [
  { icon: '🎯', title: 'Age-Appropriate Language',   desc: 'Write for 10–13 year olds. Use simple, clear language. Avoid medical jargon. Use friendly examples.' },
  { icon: '✅', title: 'Evidence-Based Content',     desc: 'All information must be verified. Cite credible sources. Do not speculate or use unverified information.' },
  { icon: '🛡️', title: 'Safe Content Policy',        desc: 'Avoid graphic descriptions. Focus on empowerment, not fear. Provide actionable, positive steps.' },
  { icon: '🎨', title: 'Format Requirements',        desc: 'Include at least 3 Do\'s and 3 Don\'ts. Add quiz questions. Keep articles between 300–600 words.' },
];

const CounselorDashboard = () => {
  const [activePage, setActivePage] = useState('create');
  const [form, setForm]             = useState({ title: '', category: '', level: 'Beginner', content: '', dos: ['', ''], donts: ['', ''] });
  const [preview, setPreview]       = useState(false);
  const [submitted, setSubmitted]   = useState(false);

  const upd = (field, val) => setForm(f => ({ ...f, [field]: val }));

  const handleReset = () => {
    setSubmitted(false);
    setForm({ title: '', category: '', level: 'Beginner', content: '', dos: ['', ''], donts: ['', ''] });
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', background: '#F5FDF9' }}>
      <Navbar role="counselor" />
      <div style={{ display: 'flex', flex: 1 }}>
        <Sidebar links={links} activePage={activePage} onNavigate={setActivePage} />
        <main style={{ flex: 1, padding: '28px 32px' }} className="page-enter">

          {/* ---- CREATE ARTICLE ---- */}
          {activePage === 'create' && (
            <div style={{ maxWidth: 760 }}>
              <SectionHeader icon="✍️" title="Create Article" subtitle="Write content for young learners" />

              {submitted ? (
                <Card style={{ textAlign: 'center', padding: 40 }}>
                  <div style={{ fontSize: 64, marginBottom: 16 }}>🎉</div>
                  <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 800, fontSize: 22, color: '#2D2D5E', marginBottom: 8 }}>
                    Article Submitted!
                  </div>
                  <div style={{ color: '#7B7BA8', marginBottom: 24 }}>
                    Your article is under review by the admin team. You'll be notified when it's approved.
                  </div>
                  <button className="btn btn-primary" onClick={handleReset}>Write Another</button>
                </Card>
              ) : (
                <Card style={{ padding: 28 }}>
                  {/* Title + Category */}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 20 }}>
                    <FormInput label="Article Title *" value={form.title} onChange={e => upd('title', e.target.value)} placeholder="Enter article title..." />
                    <div>
                      <label className="form-label">Category *</label>
                      <select className="form-input" value={form.category} onChange={e => upd('category', e.target.value)}>
                        <option value="">Select category...</option>
                        {CATEGORIES.map(c => <option key={c.id}>{c.title}</option>)}
                      </select>
                    </div>
                  </div>

                  {/* Level */}
                  <div style={{ marginBottom: 20 }}>
                    <label className="form-label">Level</label>
                    <div style={{ display: 'flex', gap: 10 }}>
                      {['Beginner', 'Intermediate', 'Advanced'].map(l => (
                        <button key={l} className="btn" onClick={() => upd('level', l)} style={{
                          background: form.level === l ? '#eef0ff' : 'white',
                          border: `2px solid ${form.level === l ? '#6C63FF' : '#e0defd'}`,
                          color:  form.level === l ? '#6C63FF' : '#7B7BA8',
                          padding: '8px 20px', borderRadius: 50,
                        }}>
                          {l}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Content */}
                  <FormInput label="Article Content *" rows={5} value={form.content}
                    onChange={e => upd('content', e.target.value)}
                    placeholder="Write the main content of your article here..." />

                  {/* Do's & Don'ts */}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 24 }}>
                    <div>
                      <label className="form-label">✅ Do's</label>
                      {form.dos.map((d, i) => (
                        <input key={i} className="form-input" style={{ marginBottom: 8 }}
                          placeholder={`Do #${i + 1}...`} value={d}
                          onChange={e => { const n = [...form.dos]; n[i] = e.target.value; upd('dos', n); }} />
                      ))}
                      <button className="btn btn-secondary btn-sm" onClick={() => upd('dos', [...form.dos, ''])}>+ Add Do</button>
                    </div>
                    <div>
                      <label className="form-label">❌ Don'ts</label>
                      {form.donts.map((d, i) => (
                        <input key={i} className="form-input" style={{ marginBottom: 8 }}
                          placeholder={`Don't #${i + 1}...`} value={d}
                          onChange={e => { const n = [...form.donts]; n[i] = e.target.value; upd('donts', n); }} />
                      ))}
                      <button className="btn btn-secondary btn-sm" onClick={() => upd('donts', [...form.donts, ''])}>+ Add Don't</button>
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: 12 }}>
                    <button className="btn btn-secondary" onClick={() => setPreview(true)}>👁 Preview</button>
                    <button className="btn btn-primary" onClick={() => setSubmitted(true)}>📤 Submit for Approval</button>
                  </div>
                </Card>
              )}

              {/* Preview Modal */}
              {preview && (
                <div className="modal-overlay" onClick={() => setPreview(false)}>
                  <div className="modal-box" onClick={e => e.stopPropagation()}>
                    <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 800, fontSize: 20, marginBottom: 16, color: '#2D2D5E' }}>
                      Preview: {form.title || 'Untitled'}
                    </div>
                    <p style={{ color: '#7B7BA8', lineHeight: 1.7, marginBottom: 20 }}>{form.content || 'No content yet.'}</p>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                      <div style={{ background: '#e6fdf8', borderRadius: 12, padding: 14 }}>
                        <div style={{ fontWeight: 800, color: '#006654', marginBottom: 8 }}>✅ Do's</div>
                        {form.dos.filter(Boolean).map((d, i) => (
                          <div key={i} style={{ fontSize: 13, color: '#006654', marginBottom: 4 }}>• {d}</div>
                        ))}
                      </div>
                      <div style={{ background: '#fff0f3', borderRadius: 12, padding: 14 }}>
                        <div style={{ fontWeight: 800, color: '#c0002a', marginBottom: 8 }}>❌ Don'ts</div>
                        {form.donts.filter(Boolean).map((d, i) => (
                          <div key={i} style={{ fontSize: 13, color: '#c0002a', marginBottom: 4 }}>• {d}</div>
                        ))}
                      </div>
                    </div>
                    <button className="btn btn-secondary" style={{ marginTop: 20 }} onClick={() => setPreview(false)}>
                      Close Preview
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ---- MY ARTICLES ---- */}
          {activePage === 'my-articles' && (
            <div>
              <SectionHeader icon="📋" title="My Articles" subtitle="Track your submission status" />
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                {myArticles.map(art => {
                  const sc = statusColor[art.status];
                  return (
                    <Card key={art.id} style={{ padding: 20, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <div>
                        <div style={{ fontWeight: 800, fontSize: 16, color: '#2D2D5E', marginBottom: 4 }}>{art.title}</div>
                        <div style={{ fontSize: 13, color: '#7B7BA8' }}>{art.category} · Submitted {art.date}</div>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                        <span className="chip" style={{ background: sc.bg, color: sc.color, textTransform: 'capitalize' }}>
                          {art.status === 'pending' ? '⏳' : art.status === 'approved' ? '✅' : '❌'} {art.status}
                        </span>
                        {art.status === 'rejected' && (
                          <button className="btn btn-secondary btn-sm">Edit & Resubmit</button>
                        )}
                      </div>
                    </Card>
                  );
                })}
              </div>
            </div>
          )}

          {/* ---- GUIDELINES ---- */}
          {activePage === 'guidelines' && (
            <div style={{ maxWidth: 680 }}>
              <SectionHeader icon="📖" title="Content Guidelines" subtitle="Ensure your content is safe and appropriate" />
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                {guidelineItems.map((g, i) => (
                  <Card key={i} style={{ padding: 20, display: 'flex', gap: 16 }}>
                    <div style={{ fontSize: 30, flexShrink: 0 }}>{g.icon}</div>
                    <div>
                      <div style={{ fontWeight: 800, color: '#2D2D5E', marginBottom: 6 }}>{g.title}</div>
                      <div style={{ fontSize: 14, color: '#7B7BA8', lineHeight: 1.6 }}>{g.desc}</div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default CounselorDashboard;
