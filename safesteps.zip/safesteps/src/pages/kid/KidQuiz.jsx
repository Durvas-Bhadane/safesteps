import React from 'react';
import { ARTICLES, CATEGORIES, QUIZ_DATA } from '../../data/data';
import Card from '../../components/Card';
import SectionHeader from '../../components/SectionHeader';

const KidQuiz = ({ onQuiz }) => (
  <div>
    <SectionHeader icon="🎯" title="Quiz Zone" subtitle="Test your knowledge and earn stars!" />
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(300px,1fr))', gap: 20 }}>
      {ARTICLES.map(art => {
        const cat  = CATEGORIES.find(c => c.id === art.categoryId);
        const quiz = QUIZ_DATA[art.quizId];
        return (
          <Card key={art.id} style={{ padding: 22 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
              <div style={{
                width: 44, height: 44, borderRadius: 12, background: cat?.bg,
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22,
              }}>
                {cat?.icon}
              </div>
              <div>
                <div style={{ fontWeight: 800, fontSize: 15, color: '#2D2D5E' }}>{quiz?.title}</div>
                <div style={{ fontSize: 12, color: '#7B7BA8' }}>{quiz?.questions.length} Questions</div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 4, marginBottom: 14 }}>
              {[1,2,3].map(s => <span key={s} style={{ fontSize: 18, opacity: 0.25 }}>⭐</span>)}
            </div>
            <button className="btn btn-primary"
              style={{ width: '100%', justifyContent: 'center' }}
              onClick={() => onQuiz(art.quizId)}>
              Start Quiz 🚀
            </button>
          </Card>
        );
      })}
    </div>
  </div>
);

export default KidQuiz;
