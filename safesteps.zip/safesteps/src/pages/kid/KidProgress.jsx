import React from 'react';
import { CATEGORIES } from '../../data/data';
import Card from '../../components/Card';
import ProgressBar from '../../components/ProgressBar';
import SectionHeader from '../../components/SectionHeader';

const progressValues = [55, 70, 40, 30, 65, 80];

const KidProgress = () => (
  <div>
    <SectionHeader icon="📈" title="My Progress" subtitle="Track your learning journey" />
    <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 24 }}>

      {/* Category Tracks */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        {CATEGORIES.map((cat, i) => {
          const pct = progressValues[i];
          return (
            <Card key={cat.id} style={{ padding: 20 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 14 }}>
                <div style={{
                  width: 44, height: 44, borderRadius: 12, background: cat.bg,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22,
                }}>
                  {cat.icon}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 800, color: '#2D2D5E', marginBottom: 2 }}>{cat.title}</div>
                  <div style={{ fontSize: 12, color: '#7B7BA8' }}>
                    {Math.round((pct / 100) * cat.articles)}/{cat.articles} articles
                  </div>
                </div>
                <div style={{ fontWeight: 800, color: cat.color, fontSize: 18 }}>{pct}%</div>
              </div>
              <ProgressBar value={pct} color={cat.color} />
            </Card>
          );
        })}
      </div>

      {/* Sidebar Stats */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <Card style={{ padding: 22, textAlign: 'center' }}>
          <div style={{ fontSize: 52, fontWeight: 900, color: '#6C63FF', fontFamily: "'Poppins',sans-serif" }}>
            57%
          </div>
          <div style={{ color: '#7B7BA8', fontWeight: 700 }}>Overall Progress</div>
          <div style={{ marginTop: 14 }}><ProgressBar value={57} /></div>
        </Card>

        <Card style={{ padding: 22 }}>
          <div style={{ fontWeight: 800, color: '#2D2D5E', marginBottom: 14 }}>🔥 Streak Calendar</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 5 }}>
            {Array.from({ length: 28 }).map((_, i) => {
              const active = [0,1,2,4,5,7,8,9,11,14,15,16,18,19,20,21].includes(i);
              return (
                <div key={i} style={{
                  width: '100%', aspectRatio: '1', borderRadius: 4,
                  background: active ? '#6C63FF' : '#E8E7FF',
                }} />
              );
            })}
          </div>
        </Card>

        <Card style={{ padding: 22 }}>
          <div style={{ fontWeight: 800, color: '#2D2D5E', marginBottom: 14 }}>⏱ Time Spent</div>
          {[
            { label: 'Today',     value: '24 min' },
            { label: 'This Week', value: '2h 40m' },
            { label: 'All Time',  value: '18h 12m' },
          ].map(t => (
            <div key={t.label} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <span style={{ fontSize: 13, color: '#7B7BA8' }}>{t.label}</span>
              <span style={{ fontSize: 13, fontWeight: 800, color: '#6C63FF' }}>{t.value}</span>
            </div>
          ))}
        </Card>
      </div>
    </div>
  </div>
);

export default KidProgress;
