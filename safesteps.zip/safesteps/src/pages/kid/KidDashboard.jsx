import React, { useState } from 'react';
import Navbar from '../../components/Navbar';
import Sidebar from '../../components/Sidebar';
import ArticleModal from '../../components/ArticleModal';
import QuizModal from '../../components/QuizModal';
import CategoryCard from '../../components/CategoryCard';
import SectionHeader from '../../components/SectionHeader';
import Card from '../../components/Card';
import KidHome from './KidHome';
import KidQuiz from './KidQuiz';
import KidBadges from './KidBadges';
import KidProgress from './KidProgress';
import { CATEGORIES, ARTICLES } from '../../data/data';

const kidLinks = [
  { id: 'home',       icon: '🏠', label: 'Home' },
  { id: 'categories', icon: '📚', label: 'Learning' },
  { id: 'quiz',       icon: '🎯', label: 'Quizzes' },
  { id: 'badges',     icon: '🏆', label: 'My Badges' },
  { id: 'progress',   icon: '📈', label: 'Progress' },
];

const KidDashboard = () => {
  const [activePage, setActivePage]       = useState('home');
  const [selectedArticle, setSelectedArticle] = useState(null);
  const [activeQuiz, setActiveQuiz]       = useState(null);
  const [selectedCat, setSelectedCat]     = useState(null);

  const openQuiz = (quizId) => { setSelectedArticle(null); setActiveQuiz(quizId); };

  const handleCatSelect = (cat) => { setSelectedCat(cat); setActivePage('articles'); };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', background: '#F4F3FF' }}>
      <Navbar role="kid" />
      <div style={{ display: 'flex', flex: 1 }}>
        <Sidebar links={kidLinks} activePage={activePage} onNavigate={setActivePage} />
        <main style={{ flex: 1, padding: '28px 32px', overflowY: 'auto' }} className="page-enter">

          {activePage === 'home' && (
            <KidHome onNavigate={setActivePage} onArticle={setSelectedArticle} />
          )}

          {activePage === 'categories' && (
            <div>
              <SectionHeader icon="📚" title="Learning Categories" subtitle="Choose a topic to explore" />
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(280px,1fr))', gap: 20 }}>
                {CATEGORIES.map(cat => (
                  <CategoryCard key={cat.id} cat={cat} onSelect={handleCatSelect} />
                ))}
              </div>
            </div>
          )}

          {activePage === 'articles' && selectedCat && (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
                <button className="btn btn-secondary btn-sm" onClick={() => setActivePage('categories')}>← Back</button>
                <SectionHeader icon={selectedCat.icon} title={selectedCat.title}
                  subtitle={`${selectedCat.articles} articles`} noMargin />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(320px,1fr))', gap: 20 }}>
                {ARTICLES.filter(a => a.categoryId === selectedCat.id).map(art => (
                  <Card key={art.id} className="card-hover" onClick={() => setSelectedArticle(art)} style={{ padding: 22 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
                      <span className="chip" style={{ background: selectedCat.bg, color: selectedCat.color }}>{art.level}</span>
                      <span style={{ fontSize: 13, color: '#7B7BA8' }}>⏱ {art.readTime}</span>
                    </div>
                    <div style={{ fontWeight: 800, fontSize: 17, color: '#2D2D5E', marginBottom: 8 }}>{art.title}</div>
                    <div style={{ fontSize: 13, color: '#7B7BA8', lineHeight: 1.6, marginBottom: 16 }}>
                      {art.content.substring(0, 90)}...
                    </div>
                    <button className="btn btn-primary btn-sm" onClick={e => { e.stopPropagation(); setSelectedArticle(art); }}>
                      Read Article →
                    </button>
                  </Card>
                ))}
                {ARTICLES.filter(a => a.categoryId === selectedCat.id).length === 0 && (
                  <div style={{ color: '#7B7BA8', padding: 24 }}>No articles yet in this category.</div>
                )}
              </div>
            </div>
          )}

          {activePage === 'quiz'     && <KidQuiz     onQuiz={openQuiz} />}
          {activePage === 'badges'   && <KidBadges />}
          {activePage === 'progress' && <KidProgress />}
        </main>
      </div>

      {selectedArticle && (
        <ArticleModal article={selectedArticle} onClose={() => setSelectedArticle(null)} onQuiz={openQuiz} />
      )}
      {activeQuiz && (
        <QuizModal quizId={activeQuiz} onClose={() => setActiveQuiz(null)} />
      )}
    </div>
  );
};

export default KidDashboard;
