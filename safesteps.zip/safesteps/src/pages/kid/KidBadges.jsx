import React from 'react';
import { BADGES } from '../../data/data';
import BadgeCard from '../../components/BadgeCard';
import SectionHeader from '../../components/SectionHeader';

const KidBadges = () => (
  <div>
    <SectionHeader
      icon="🏆"
      title="My Badges"
      subtitle={`${BADGES.filter(b => b.earned).length} of ${BADGES.length} earned`}
    />
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(200px,1fr))', gap: 20 }}>
      {BADGES.map(badge => <BadgeCard key={badge.id} badge={badge} />)}
    </div>
  </div>
);

export default KidBadges;
