import React from 'react';
import { CATEGORIES, ARTICLES } from '../../data/data';
import CategoryCard from '../../components/CategoryCard';
import StatCard from '../../components/StatCard';
import Card from '../../components/Card';
import SectionHeader from '../../components/SectionHeader';

const KidHome = ({ onNavigate, onArticle }) => (
  <div>
    {/* Welcome Banner */}
    <div style={{
      background: 'linear-gradient(135deg,#6C63FF 0%,#9B8FFF 50%,#C4BEFF 100%)',
      borderRadius: 24, padding: '28px 32px', marginBottom: 28,
      position: 'relative', overflow: 'hidden',
      color: 'white', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    }}>
      <div style={{
        position: 'absolute', right: 0, top: 0, width: 200, height: 200,
        background: 'rgba(255,255,255,0.08)', borderRadius: '50%', transform: 'translate(60px,-60px)',
      }} />
      <div>
        <div style={{ fontFamily: "'Poppins',sans-serif", fontSize: 26, fontWeight: 800, marginBottom: 8 }}>
          Hey Aarav! 👋
        </div>
        <div style={{ fontSize: 15, opacity: 0.85, marginBottom: 16 }}>
          You're on a 5-day learning streak! Keep it up! 🔥
        </div>
        <button className="btn" style={{ background: 'white', color: '#6C63FF' }} onClick={() => onNavigate('categories')}>
          Continue Learning →
        </button>
      </div>
      <div className="float-anim" style={{ fontSize: 80, userSelect: 'none' }}>🎓</div>
    </div>

    {/* Stats */}
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 16, marginBottom: 28 }}>
      <StatCard icon="📖" value="12" label="Articles Read" color="#6C63FF" bg="#EEF0FF" />
      <StatCard icon="🎯" value="8"  label="Quizzes Done"  color="#FF6B8B" bg="#FFF0F3" />
      <StatCard icon="🏆" value="3"  label="Badges Earned" color="#FFB84D" bg="#FFF8EC" />
      <StatCard icon="🔥" value="5"  label="Day Streak"    color="#FF7043" bg="#FFF3F0" />
    </div>

    {/* Categories Preview */}
    <SectionHeader icon="📚" title="Continue Learning" subtitle="Pick up where you left off" />
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(260px,1fr))', gap: 16, marginBottom: 28 }}>
      {CATEGORIES.slice(0, 3).map(cat => (
        <CategoryCard key={cat.id} cat={cat} onSelect={() => onNavigate('categories')} />
      ))}
    </div>

    {/* Recent Articles */}
    <SectionHeader icon="📰" title="Recent Articles" subtitle="Latest verified content for you" />
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(300px,1fr))', gap: 16 }}>
      {ARTICLES.slice(0, 3).map(art => {
        const cat = CATEGORIES.find(c => c.id === art.categoryId);
        return (
          <Card key={art.id} className="card-hover" onClick={() => onArticle(art)}
            style={{ padding: 20, display: 'flex', gap: 14, alignItems: 'flex-start' }}>
            <div style={{
              width: 44, height: 44, borderRadius: 12, background: cat?.bg,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 22, flexShrink: 0,
            }}>
              {cat?.icon}
            </div>
            <div>
              <div style={{ fontWeight: 800, fontSize: 15, color: '#2D2D5E', marginBottom: 4 }}>{art.title}</div>
              <div style={{ fontSize: 12, color: '#7B7BA8' }}>{art.author} · {art.readTime}</div>
            </div>
          </Card>
        );
      })}
    </div>
  </div>
);

export default KidHome;
