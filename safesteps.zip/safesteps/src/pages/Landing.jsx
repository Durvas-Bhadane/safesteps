import React from 'react';
import Logo from '../components/Logo';

const roles = [
  { role: 'kid',       icon: '🧒', title: "I'm a Kid",       desc: 'Learn, explore & earn badges',    color: '#6C63FF', grad: 'linear-gradient(135deg,#6C63FF,#9B8FFF)' },
  { role: 'counselor', icon: '👩‍⚕️', title: "I'm a Counselor", desc: 'Create and share knowledge',    color: '#00C9A7', grad: 'linear-gradient(135deg,#00C9A7,#00E5C4)' },
  { role: 'admin',     icon: '🧑‍💼', title: "I'm an Admin",    desc: 'Review and manage content',     color: '#5C6BC0', grad: 'linear-gradient(135deg,#5C6BC0,#8B91DC)' },
];

const features = [
  { icon: '🛡️', label: 'Verified Content' },
  { icon: '🎮', label: 'Gamified Learning' },
  { icon: '🔒', label: '100% Safe' },
  { icon: '📚', label: 'Expert Curated' },
];

const Landing = ({ onSelect }) => (
  <div style={{
    minHeight: '100vh',
    background: 'linear-gradient(160deg,#F4F3FF 0%,#EFF9F6 50%,#FFF5F7 100%)',
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    justifyContent: 'center', padding: 32,
  }}>
    <div className="float-anim" style={{ marginBottom: 20 }}>
      <Logo size={72} />
    </div>

    <h1 style={{
      fontFamily: "'Poppins',sans-serif", fontSize: 42, fontWeight: 900,
      color: '#2D2D5E', textAlign: 'center', marginBottom: 8,
    }}>
      Safe<span style={{ color: '#6C63FF' }}>Steps</span>
    </h1>

    <p style={{ color: '#7B7BA8', fontSize: 18, textAlign: 'center', maxWidth: 500, marginBottom: 48, lineHeight: 1.6 }}>
      A safe, fun, and trusted learning space for young explorers aged 10–13 🌟
    </p>

    <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', justifyContent: 'center' }}>
      {roles.map(r => (
        <div key={r.role} className="card-hover" onClick={() => onSelect(r.role)} style={{
          background: 'white', borderRadius: 24, padding: '32px 28px',
          boxShadow: '0 4px 24px rgba(108,99,255,0.10)',
          cursor: 'pointer', width: 220, textAlign: 'center',
        }}>
          <div style={{
            width: 72, height: 72, borderRadius: 20, background: r.grad,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 36, margin: '0 auto 18px',
            boxShadow: `0 8px 24px ${r.color}40`,
          }}>
            {r.icon}
          </div>
          <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 800, fontSize: 18, color: '#2D2D5E', marginBottom: 8 }}>
            {r.title}
          </div>
          <div style={{ fontSize: 13, color: '#7B7BA8', lineHeight: 1.5 }}>{r.desc}</div>
        </div>
      ))}
    </div>

    <div style={{ marginTop: 48, display: 'flex', gap: 28, flexWrap: 'wrap', justifyContent: 'center' }}>
      {features.map(f => (
        <div key={f.label} style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#7B7BA8', fontSize: 14, fontWeight: 700 }}>
          <span>{f.icon}</span>{f.label}
        </div>
      ))}
    </div>
  </div>
);

export default Landing;
