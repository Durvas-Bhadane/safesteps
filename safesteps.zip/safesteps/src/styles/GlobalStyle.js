import React from 'react';
import theme from './theme';

const GlobalStyle = () => (
  <style>{`
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Nunito', sans-serif;
      background: ${theme.bg};
      color: ${theme.text};
      min-height: 100vh;
    }

    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: #f0f0f0; }
    ::-webkit-scrollbar-thumb { background: #c5c2f5; border-radius: 10px; }

    .page-enter {
      animation: pageIn 0.4s cubic-bezier(0.22, 1, 0.36, 1) forwards;
    }
    @keyframes pageIn {
      from { opacity: 0; transform: translateY(18px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    .card-hover {
      transition: transform 0.22s cubic-bezier(0.22,1,0.36,1), box-shadow 0.22s ease;
      cursor: pointer;
    }
    .card-hover:hover {
      transform: translateY(-5px) scale(1.025);
      box-shadow: ${theme.shadowHover};
    }

    /* ---- BUTTONS ---- */
    .btn {
      display: inline-flex; align-items: center; gap: 8px;
      border: none; border-radius: 50px; font-family: 'Nunito', sans-serif;
      font-weight: 700; cursor: pointer; transition: all 0.2s ease;
      text-decoration: none;
    }
    .btn-primary {
      background: linear-gradient(135deg, #6C63FF, #9B8FFF);
      color: white; padding: 10px 22px; font-size: 15px;
      box-shadow: 0 4px 14px rgba(108,99,255,0.35);
    }
    .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(108,99,255,0.45); }
    .btn-secondary {
      background: white; color: ${theme.primary}; padding: 10px 22px;
      font-size: 15px; border: 2px solid #e0defd;
    }
    .btn-secondary:hover { background: #f5f4ff; transform: translateY(-2px); }
    .btn-danger  { background: linear-gradient(135deg,#FF6B8B,#FF8FA3); color:white; padding:8px 18px; font-size:14px; }
    .btn-success { background: linear-gradient(135deg,#00C9A7,#00E5C4); color:white; padding:8px 18px; font-size:14px; }
    .btn-sm { padding: 7px 16px; font-size: 13px; }

    /* ---- CHIP ---- */
    .chip {
      display: inline-block; border-radius: 50px; font-size: 12px;
      font-weight: 700; padding: 3px 12px;
    }

    /* ---- BADGES ---- */
    .badge-earned { filter: drop-shadow(0 2px 8px rgba(108,99,255,0.3)); }
    .badge-locked { filter: grayscale(1) opacity(0.4); }

    /* ---- QUIZ ---- */
    .quiz-option {
      border: 2px solid #e0defd; border-radius: 14px; padding: 14px 18px;
      cursor: pointer; transition: all 0.18s ease; background: white;
      font-family: 'Nunito', sans-serif; font-size: 15px; font-weight: 600;
      color: ${theme.text}; text-align: left; width: 100%;
    }
    .quiz-option:hover   { border-color: #6C63FF; background: #f5f4ff; transform: translateX(4px); }
    .quiz-option.selected { border-color: #6C63FF; background: #eef0ff; }
    .quiz-option.correct  { border-color: #00C9A7; background: #e6fdf8; color: #006654; }
    .quiz-option.wrong    { border-color: #FF6B8B; background: #fff0f3; color: #c0002a; }

    /* ---- PROGRESS BAR ---- */
    .progress-bar-track {
      height: 10px; background: #E8E7FF; border-radius: 50px; overflow: hidden;
    }
    .progress-bar-fill {
      height: 100%; border-radius: 50px;
      background: linear-gradient(90deg, #6C63FF, #9B8FFF);
      transition: width 0.8s cubic-bezier(0.22,1,0.36,1);
    }

    /* ---- STARS ---- */
    .star { display: inline-block; font-size: 28px; transition: transform 0.2s ease; }
    .star.lit { animation: starPop 0.3s ease forwards; }
    @keyframes starPop {
      0%   { transform: scale(0.5); }
      70%  { transform: scale(1.2); }
      100% { transform: scale(1); }
    }

    /* ---- SIDEBAR LINK ---- */
    .sidebar-link {
      display: flex; align-items: center; gap: 12px; padding: 12px 16px;
      border-radius: 14px; color: ${theme.textLight}; font-weight: 700;
      cursor: pointer; transition: all 0.18s ease; font-size: 15px;
      text-decoration: none; border: none; background: none; width: 100%;
    }
    .sidebar-link:hover  { background: #f0f0fd; color: ${theme.primary}; }
    .sidebar-link.active { background: linear-gradient(135deg,#eef0ff,#e8e6ff); color: ${theme.primary}; }

    /* ---- FORM ---- */
    .form-input {
      width: 100%; border: 2px solid #e0defd; border-radius: 12px;
      padding: 12px 16px; font-family: 'Nunito', sans-serif; font-size: 15px;
      color: ${theme.text}; outline: none; transition: border-color 0.2s ease;
      background: white;
    }
    .form-input:focus { border-color: #6C63FF; box-shadow: 0 0 0 3px rgba(108,99,255,0.1); }
    .form-label {
      font-size: 14px; font-weight: 700; color: ${theme.textLight};
      margin-bottom: 6px; display: block;
    }

    /* ---- TABLE ---- */
    .table-row:hover { background: #fafafe; }

    /* ---- FLOAT ANIMATION ---- */
    @keyframes float {
      0%, 100% { transform: translateY(0px); }
      50%       { transform: translateY(-8px); }
    }
    .float-anim { animation: float 3s ease-in-out infinite; }

    /* ---- NOTIFICATION DOT ---- */
    .notification-dot { position: relative; }
    .notification-dot::after {
      content: ''; position: absolute; top: 4px; right: 4px;
      width: 10px; height: 10px; background: #FF6B8B; border-radius: 50%;
      border: 2px solid white;
    }

    /* ---- MODAL ---- */
    .modal-overlay {
      position: fixed; inset: 0; background: rgba(45,45,94,0.45);
      backdrop-filter: blur(4px); z-index: 1000;
      display: flex; align-items: center; justify-content: center;
      animation: fadeIn 0.2s ease;
    }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .modal-box {
      background: white; border-radius: 24px; padding: 32px;
      max-width: 560px; width: 94%; max-height: 90vh; overflow-y: auto;
      animation: slideUp 0.3s cubic-bezier(0.22,1,0.36,1);
    }
    @keyframes slideUp {
      from { transform: translateY(30px); opacity: 0; }
      to   { transform: translateY(0);    opacity: 1; }
    }
  `}</style>
);

export default GlobalStyle;
