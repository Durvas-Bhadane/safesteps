export const theme = {
  primary: "#6C63FF",
  secondary: "#FF6B8B",
  accent: "#00C9A7",
  warning: "#FFB84D",
  bg: "#F4F3FF",
  cardBg: "#FFFFFF",
  text: "#2D2D5E",
  textLight: "#7B7BA8",
  shadow: "0 4px 24px rgba(108,99,255,0.10)",
  shadowHover: "0 8px 32px rgba(108,99,255,0.18)",
  radius: "20px",
  radiusSm: "12px",
};

export default theme;
