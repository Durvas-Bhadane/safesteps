import React, { useState } from 'react';
import GlobalStyle from './styles/GlobalStyle';
import Landing from './pages/Landing';
import KidDashboard from './pages/kid/KidDashboard';
import CounselorDashboard from './pages/counselor/CounselorDashboard';
import AdminDashboard from './pages/admin/AdminDashboard';

/*
 * ROLE-BASED ROUTING
 * -------------------------------------------------
 * This uses simple state-based routing for now.
 * When you integrate React Router DOM (already in package.json),
 * replace this with:
 *
 *   <Routes>
 *     <Route path="/"                    element={<Landing />} />
 *     <Route path="/kid/dashboard"       element={<KidDashboard />} />
 *     <Route path="/kid/quiz"            element={<KidDashboard />} />
 *     <Route path="/counselor/create"    element={<CounselorDashboard />} />
 *     <Route path="/admin/approval"      element={<AdminDashboard />} />
 *   </Routes>
 *
 * And wrap in <BrowserRouter> inside index.js.
 * Add a PrivateRoute wrapper for JWT-based auth.
 * -------------------------------------------------
 */

const App = () => {
  const [role, setRole] = useState(null); // null | 'kid' | 'counselor' | 'admin'

  return (
    <>
      <GlobalStyle />

      {!role         && <Landing onSelect={setRole} />}
      {role === 'kid'       && <KidDashboard />}
      {role === 'counselor' && <CounselorDashboard />}
      {role === 'admin'     && <AdminDashboard />}

      {/* Demo role switcher — remove in production */}
      {role && (
        <div style={{ position: 'fixed', bottom: 20, right: 20, zIndex: 999 }}>
          <button
            className="btn btn-secondary"
            style={{ boxShadow: '0 8px 32px rgba(108,99,255,0.18)', background: 'white' }}
            onClick={() => setRole(null)}
          >
            ← Switch Role
          </button>
        </div>
      )}
    </>
  );
};

export default App;
