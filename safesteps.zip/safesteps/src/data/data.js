export const CATEGORIES = [
  { id: 1, icon: "🛡️", title: "Personal Safety", desc: "Learn how to stay safe online and offline", color: "#6C63FF", bg: "#EEF0FF", articles: 8, badge: "Safety Star" },
  { id: 2, icon: "💬", title: "Emotions & Feelings", desc: "Understanding your feelings and how to express them", color: "#FF6B8B", bg: "#FFF0F3", articles: 6, badge: "Emotion Explorer" },
  { id: 3, icon: "🌐", title: "Digital Citizenship", desc: "Be smart and responsible online", color: "#00C9A7", bg: "#E6FDF8", articles: 7, badge: "Cyber Guardian" },
  { id: 4, icon: "🤝", title: "Healthy Relationships", desc: "Friendships, respect and boundaries", color: "#FFB84D", bg: "#FFF8EC", articles: 5, badge: "Friend Hero" },
  { id: 5, icon: "💪", title: "Body Confidence", desc: "Love yourself and understand body changes", color: "#FF7043", bg: "#FFF3F0", articles: 6, badge: "Body Positive" },
  { id: 6, icon: "🧠", title: "Mental Wellness", desc: "Tips to keep your mind healthy and happy", color: "#5C6BC0", bg: "#F0F1FF", articles: 9, badge: "Mind Master" },
];

export const ARTICLES = [
  {
    id: 1, categoryId: 1, title: "Staying Safe Online", status: "approved",
    author: "Dr. Priya Sharma", readTime: "5 min", level: "Beginner",
    content: "The internet is a wonderful place to learn and connect, but it's important to stay safe. Understanding basic online safety rules can protect you from strangers and harmful content.",
    dos: [
      "Tell a trusted adult if something makes you uncomfortable online",
      "Use strong passwords and keep them private",
      "Only talk to people you know in real life",
      "Think before you post anything",
    ],
    donts: [
      "Share personal information like your address or phone number",
      "Meet someone you only know online without a trusted adult",
      "Click on unknown links or pop-ups",
      "Accept friend requests from strangers",
    ],
    quizId: 1,
  },
  {
    id: 2, categoryId: 2, title: "Understanding Anger", status: "approved",
    author: "Dr. Arjun Mehta", readTime: "4 min", level: "Beginner",
    content: "Anger is a normal emotion. Everyone feels angry sometimes, but how we handle it matters. Learning to manage anger in healthy ways helps us build better relationships and feel better ourselves.",
    dos: [
      "Take deep breaths when you feel angry",
      "Count to 10 before reacting",
      "Talk to someone you trust about your feelings",
      "Write in a journal to express your emotions",
    ],
    donts: [
      "Hit or hurt someone when angry",
      "Say mean things you'll regret later",
      "Bottle up your feelings for too long",
      "Make big decisions when you're very angry",
    ],
    quizId: 2,
  },
  {
    id: 3, categoryId: 3, title: "Cyberbullying: Know & Act", status: "approved",
    author: "Ms. Kavya Nair", readTime: "6 min", level: "Intermediate",
    content: "Cyberbullying happens when someone uses technology to repeatedly hurt or intimidate another person. It can happen on social media, in games, or through messages. It's never okay and you don't have to face it alone.",
    dos: [
      "Save screenshots as evidence",
      "Block the person bullying you",
      "Tell a trusted adult immediately",
      "Support friends who are being bullied",
    ],
    donts: [
      "Respond to cyberbullies — it makes it worse",
      "Share or spread hurtful content",
      "Suffer in silence",
      "Retaliate with more bullying",
    ],
    quizId: 3,
  },
  {
    id: 4, categoryId: 4, title: "What Are Healthy Friendships?", status: "approved",
    author: "Dr. Priya Sharma", readTime: "5 min", level: "Beginner",
    content: "Healthy friendships are built on respect, trust, and kindness. Knowing what a good friendship looks like helps you make better choices about who you spend time with.",
    dos: [
      "Be honest and kind with your friends",
      "Respect each other's boundaries",
      "Support each other during tough times",
      "Celebrate each other's success",
    ],
    donts: [
      "Pressure friends to do things they don't want to",
      "Share secrets your friend told you in confidence",
      "Stay in friendships that make you feel bad about yourself",
      "Leave friends out on purpose to hurt them",
    ],
    quizId: 1,
  },
  {
    id: 5, categoryId: 6, title: "Managing Stress at School", status: "approved",
    author: "Dr. Arjun Mehta", readTime: "5 min", level: "Intermediate",
    content: "Feeling stressed at school is very common. Exams, friendships, and growing up can all feel overwhelming. But there are healthy ways to manage stress and feel more in control.",
    dos: [
      "Break big tasks into smaller steps",
      "Take short breaks during study sessions",
      "Get enough sleep every night",
      "Talk to a trusted adult when you're overwhelmed",
    ],
    donts: [
      "Stay up all night studying before an exam",
      "Skip meals when stressed",
      "Keep all your worries to yourself",
      "Compare yourself constantly to others",
    ],
    quizId: 2,
  },
];

export const QUIZ_DATA = {
  1: {
    title: "Online Safety Quiz",
    questions: [
      {
        id: 1,
        question: "What should you do if a stranger online asks for your home address?",
        options: ["Give it to them if they seem nice", "Refuse and tell a trusted adult", "Ask them why they need it first", "Give a fake address"],
        correct: 1,
      },
      {
        id: 2,
        question: "Which of these is a strong password?",
        options: ["password123", "yourname2010", "Tr@1n!ng#99", "12345678"],
        correct: 2,
      },
      {
        id: 3,
        question: "You receive a suspicious link from an unknown number. What do you do?",
        options: ["Click it — maybe it's fun", "Forward it to friends", "Delete it and tell an adult", "Reply asking who sent it"],
        correct: 2,
      },
      {
        id: 4,
        question: "How often should you update your passwords?",
        options: ["Never, once is enough", "Every few months", "Every 10 years", "Only when hacked"],
        correct: 1,
      },
    ],
  },
  2: {
    title: "Emotions & Feelings Quiz",
    questions: [
      {
        id: 1,
        question: "What's the best first step when you feel very angry?",
        options: ["Yell at the nearest person", "Take deep breaths and count to 10", "Break something to release tension", "Ignore the feeling completely"],
        correct: 1,
      },
      {
        id: 2,
        question: "Anger is:",
        options: ["Always a bad emotion", "A normal human emotion", "Only felt by bad people", "A sign of weakness"],
        correct: 1,
      },
      {
        id: 3,
        question: "If your friend is very upset, you should:",
        options: ["Laugh it off", "Listen without judgment", "Tell them to stop being dramatic", "Ignore them"],
        correct: 1,
      },
    ],
  },
  3: {
    title: "Cyberbullying Awareness Quiz",
    questions: [
      {
        id: 1,
        question: "Cyberbullying is:",
        options: ["Only when done face-to-face", "Using technology to repeatedly hurt someone", "Playing rough video games", "Having arguments in games"],
        correct: 1,
      },
      {
        id: 2,
        question: "If you're being cyberbullied, the FIRST thing you should do is:",
        options: ["Fight back online", "Tell a trusted adult", "Delete all your accounts", "Pretend it's not happening"],
        correct: 1,
      },
      {
        id: 3,
        question: "What should you do with evidence of cyberbullying?",
        options: ["Delete it immediately", "Save screenshots to show an adult", "Send it to everyone", "Reply to each message"],
        correct: 1,
      },
    ],
  },
};

export const BADGES = [
  { id: 1, icon: "⭐", title: "First Step", desc: "Completed your first article", earned: true, color: "#FFD700" },
  { id: 2, icon: "🛡️", title: "Safety Star", desc: "Aced the Online Safety quiz", earned: true, color: "#6C63FF" },
  { id: 3, icon: "🧠", title: "Mind Master", desc: "Completed Mental Wellness track", earned: false, color: "#5C6BC0" },
  { id: 4, icon: "🌐", title: "Cyber Guardian", desc: "Finished Digital Citizenship", earned: true, color: "#00C9A7" },
  { id: 5, icon: "💬", title: "Emotion Explorer", desc: "Understand all 6 emotions", earned: false, color: "#FF6B8B" },
  { id: 6, icon: "🤝", title: "Friend Hero", desc: "Completed Relationships track", earned: false, color: "#FFB84D" },
];

export const PENDING_ARTICLES = [
  { id: 1, title: "Understanding Peer Pressure", author: "Ms. Kavya Nair", category: "Healthy Relationships", submitted: "2024-01-15", status: "pending" },
  { id: 2, title: "Screen Time & Mental Health", author: "Dr. Arjun Mehta", category: "Mental Wellness", submitted: "2024-01-14", status: "pending" },
  { id: 3, title: "Recognizing Grooming Behavior", author: "Dr. Priya Sharma", category: "Personal Safety", submitted: "2024-01-13", status: "pending" },
];
