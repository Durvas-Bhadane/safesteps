import React from 'react';
import Logo from './Logo';

const roleConfig = {
  kid:       { label: 'Kid Zone 🎮',      initials: 'AK', color: '#6C63FF' },
  counselor: { label: 'Counselor Portal', initials: 'CS', color: '#00C9A7' },
  admin:     { label: 'Admin Panel',      initials: 'AD', color: '#5C6BC0' },
};

const Navbar = ({ role }) => {
  const rc = roleConfig[role] || roleConfig.kid;

  return (
    <nav style={{
      background: 'white', borderBottom: '2px solid #f0efff',
      padding: '0 28px', height: 64, display: 'flex', alignItems: 'center',
      justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100,
      boxShadow: '0 2px 16px rgba(108,99,255,0.07)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <Logo size={36} />
        <div>
          <div style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 800, fontSize: 18, color: '#2D2D5E', lineHeight: 1.1 }}>
            SafeSteps
          </div>
          <div style={{ fontSize: 11, color: '#7B7BA8', fontWeight: 600 }}>{rc.label}</div>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <button className="notification-dot" style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 8 }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#7B7BA8" strokeWidth="2">
            <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0"/>
          </svg>
        </button>
        <div style={{
          width: 38, height: 38, borderRadius: '50%',
          background: `linear-gradient(135deg, ${rc.color}, ${rc.color}99)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: 'white', fontWeight: 800, fontSize: 14, cursor: 'pointer',
        }}>
          {rc.initials}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
