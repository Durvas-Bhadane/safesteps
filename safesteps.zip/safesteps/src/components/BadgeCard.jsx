import React from 'react';
import Card from './Card';

const BadgeCard = ({ badge }) => (
  <Card
    style={{ textAlign: 'center', padding: 28 }}
    className={`card-hover ${badge.earned ? '' : 'badge-locked'}`}
  >
    <div className={badge.earned ? 'badge-earned' : ''} style={{ fontSize: 52, marginBottom: 12 }}>
      {badge.icon}
    </div>
    <div style={{ fontWeight: 800, fontSize: 16, color: badge.earned ? badge.color : '#7B7BA8', marginBottom: 6 }}>
      {badge.title}
    </div>
    <div style={{ fontSize: 12, color: '#7B7BA8' }}>{badge.desc}</div>
    {badge.earned
      ? <div className="chip" style={{ background: '#e6fdf8', color: '#006654', marginTop: 12 }}>✓ Earned</div>
      : <div className="chip" style={{ background: '#f5f5f5', color: '#7B7BA8', marginTop: 12 }}>🔒 Locked</div>
    }
  </Card>
);

export default BadgeCard;
