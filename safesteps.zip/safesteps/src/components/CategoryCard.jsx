import React from 'react';
import Card from './Card';
import ProgressBar from './ProgressBar';

const CategoryCard = ({ cat, onSelect }) => (
  <Card className="card-hover" onClick={() => onSelect(cat)} style={{ padding: 20 }}>
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 12 }}>
      <div style={{
        width: 52, height: 52, borderRadius: 16, background: cat.bg,
        display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26,
      }}>
        {cat.icon}
      </div>
      <span className="chip" style={{ background: cat.bg, color: cat.color }}>
        {cat.articles} Articles
      </span>
    </div>
    <div style={{ fontWeight: 800, fontSize: 16, color: '#2D2D5E', marginBottom: 6 }}>{cat.title}</div>
    <div style={{ fontSize: 13, color: '#7B7BA8', lineHeight: 1.5, marginBottom: 14 }}>{cat.desc}</div>
    <ProgressBar value={45} color={cat.color} />
    <div style={{ fontSize: 12, color: '#7B7BA8', marginTop: 6, fontWeight: 600 }}>45% Complete</div>
  </Card>
);

export default CategoryCard;
