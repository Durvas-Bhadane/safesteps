import React from 'react';

const FormInput = ({ label, type = 'text', value, onChange, placeholder, rows }) => (
  <div style={{ marginBottom: 16 }}>
    {label && <label className="form-label">{label}</label>}
    {rows ? (
      <textarea
        className="form-input"
        rows={rows}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
      />
    ) : (
      <input
        className="form-input"
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
      />
    )}
  </div>
);

export default FormInput;
