import React from 'react';

const theme = {
  shadow: '0 4px 24px rgba(108,99,255,0.10)',
  radius: '20px',
};

const Card = ({ children, style = {}, className = '', onClick }) => (
  <div
    className={`card-hover ${className}`}
    onClick={onClick}
    style={{
      background: 'white',
      borderRadius: theme.radius,
      boxShadow: theme.shadow,
      padding: 24,
      ...style,
    }}
  >
    {children}
  </div>
);

export default Card;
