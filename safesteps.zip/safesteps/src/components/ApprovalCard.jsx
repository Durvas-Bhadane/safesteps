import React from 'react';
import Card from './Card';

const ApprovalCard = ({ article, onApprove, onReject, onReview }) => (
  <Card style={{ padding: 20 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
      <div>
        <div style={{ fontWeight: 800, fontSize: 16, color: '#2D2D5E', marginBottom: 4 }}>{article.title}</div>
        <div style={{ fontSize: 13, color: '#7B7BA8' }}>
          {article.author} · {article.category} · Submitted {article.submitted}
        </div>
      </div>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <button className="btn btn-secondary btn-sm" onClick={() => onReview(article)}>Review</button>
        <button className="btn btn-success btn-sm" onClick={() => onApprove(article.id)}>✅ Approve</button>
        <button className="btn btn-danger btn-sm"  onClick={() => onReject(article.id)}>❌ Reject</button>
      </div>
    </div>
  </Card>
);

export default ApprovalCard;
