import React from 'react';
import Card from './Card';

const StatCard = ({ icon, value, label, color, bg }) => (
  <Card style={{ textAlign: 'center', padding: '20px 16px' }}>
    <div style={{
      width: 52, height: 52, borderRadius: 16, background: bg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: 26, margin: '0 auto 12px',
    }}>
      {icon}
    </div>
    <div style={{ fontSize: 28, fontWeight: 900, color, fontFamily: "'Poppins',sans-serif" }}>
      {value}
    </div>
    <div style={{ fontSize: 13, color: '#7B7BA8', fontWeight: 600 }}>{label}</div>
  </Card>
);

export default StatCard;
