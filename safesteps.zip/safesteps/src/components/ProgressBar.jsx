import React from 'react';

const ProgressBar = ({ value, max = 100, color = '#6C63FF' }) => (
  <div className="progress-bar-track">
    <div
      className="progress-bar-fill"
      style={{
        width: `${(value / max) * 100}%`,
        background: `linear-gradient(90deg, ${color}, ${color}99)`,
      }}
    />
  </div>
);

export default ProgressBar;
