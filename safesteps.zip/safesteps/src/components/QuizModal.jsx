import React, { useState } from 'react';
import { QUIZ_DATA } from '../data/data';
import ProgressBar from './ProgressBar';

const QuizModal = ({ quizId, onClose }) => {
  const quiz = QUIZ_DATA[quizId];
  const [current, setCurrent]     = useState(0);
  const [selected, setSelected]   = useState(null);
  const [answers, setAnswers]     = useState([]);
  const [submitted, setSubmitted] = useState(false);
  const [showResult, setShowResult] = useState(false);

  if (!quiz) return null;

  const q     = quiz.questions[current];
  const score = answers.filter((a, i) => a === quiz.questions[i].correct).length;
  const stars = score === quiz.questions.length ? 3 : score >= quiz.questions.length * 0.6 ? 2 : 1;
  const pct   = Math.round((score / quiz.questions.length) * 100);

  const handleNext = () => {
    const newAnswers = [...answers, selected];
    setAnswers(newAnswers);
    if (current < quiz.questions.length - 1) {
      setCurrent(c => c + 1);
      setSelected(null);
      setSubmitted(false);
    } else {
      setShowResult(true);
    }
  };

  const handleRetry = () => {
    setCurrent(0); setSelected(null);
    setAnswers([]); setSubmitted(false); setShowResult(false);
  };

  if (showResult) {
    const msg = pct === 100
      ? 'Perfect! You\'re a superstar! 🌟'
      : pct >= 60
        ? 'Great job! Keep learning! 🎉'
        : 'Good try! Review and retry! 💪';

    return (
      <div className="modal-overlay" onClick={onClose}>
        <div className="modal-box" style={{ textAlign: 'center' }} onClick={e => e.stopPropagation()}>
          <div style={{ fontSize: 64, marginBottom: 12 }}>🏆</div>
          <div style={{ fontFamily: "'Poppins',sans-serif", fontWeight: 800, fontSize: 26, color: '#2D2D5E', marginBottom: 8 }}>
            {quiz.title} Complete!
          </div>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginBottom: 16 }}>
            {[1,2,3].map(s => (
              <span key={s} className={`star ${s <= stars ? 'lit' : ''}`}
                style={{ opacity: s <= stars ? 1 : 0.25, animationDelay: `${s * 0.15}s` }}>⭐</span>
            ))}
          </div>
          <div style={{ fontSize: 48, fontWeight: 900, color: '#6C63FF', fontFamily: "'Poppins',sans-serif", marginBottom: 8 }}>
            {pct}%
          </div>
          <div style={{ color: '#7B7BA8', marginBottom: 8 }}>{score} out of {quiz.questions.length} correct</div>
          <div style={{
            background: pct >= 60 ? '#e6fdf8' : '#fff0f3',
            borderRadius: 16, padding: 16, marginBottom: 24,
            color: pct >= 60 ? '#006654' : '#c0002a', fontWeight: 700, fontSize: 16,
          }}>
            {msg}
          </div>
          <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
            <button className="btn btn-primary" onClick={handleRetry}>🔄 Retry</button>
            <button className="btn btn-secondary" onClick={onClose}>Done</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={e => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <div style={{ fontWeight: 800, color: '#2D2D5E', fontSize: 18 }}>{quiz.title}</div>
          <span className="chip" style={{ background: '#eef0ff', color: '#6C63FF' }}>
            Q {current + 1}/{quiz.questions.length}
          </span>
        </div>
        <ProgressBar value={current + 1} max={quiz.questions.length} />
        <div style={{ marginTop: 24, marginBottom: 20, fontWeight: 700, fontSize: 17, color: '#2D2D5E', lineHeight: 1.5 }}>
          {q.question}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 24 }}>
          {q.options.map((opt, idx) => {
            let cls = 'quiz-option';
            if (submitted) {
              if (idx === q.correct)       cls += ' correct';
              else if (idx === selected)   cls += ' wrong';
            } else if (selected === idx)   cls += ' selected';
            return (
              <button key={idx} className={cls} onClick={() => !submitted && setSelected(idx)}>
                {opt}
              </button>
            );
          })}
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          {!submitted && (
            <button className="btn btn-secondary" disabled={selected === null}
              onClick={() => setSubmitted(true)} style={{ flex: 1, justifyContent: 'center' }}>
              Check Answer
            </button>
          )}
          {submitted && (
            <button className="btn btn-primary" onClick={handleNext} style={{ flex: 1, justifyContent: 'center' }}>
              {current < quiz.questions.length - 1 ? 'Next Question →' : 'See Results 🏆'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default QuizModal;
