import React from 'react';

const Logo = ({ size = 36 }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M24 4L8 11v12c0 9.4 6.8 18.2 16 20.4C33.2 41.2 40 32.4 40 23V11L24 4z"
      fill="#6C63FF" opacity="0.15"/>
    <path d="M24 4L8 11v12c0 9.4 6.8 18.2 16 20.4C33.2 41.2 40 32.4 40 23V11L24 4z"
      stroke="#6C63FF" strokeWidth="2.5" strokeLinejoin="round"/>
    <path d="M16 24l5 5 11-11"
      stroke="#00C9A7" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M30 12l2 2-2 2" stroke="#FFB84D" strokeWidth="1.5" strokeLinecap="round"/>
    <circle cx="32" cy="12" r="3" fill="#FFB84D" opacity="0.7"/>
  </svg>
);

export default Logo;
