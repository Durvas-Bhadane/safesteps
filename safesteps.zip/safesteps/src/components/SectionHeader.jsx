import React from 'react';

const SectionHeader = ({ icon, title, subtitle, noMargin }) => (
  <div style={{ marginBottom: noMargin ? 0 : 24 }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
      <span style={{ fontSize: 24 }}>{icon}</span>
      <h2 style={{
        fontFamily: "'Poppins',sans-serif", fontWeight: 800,
        fontSize: 22, color: '#2D2D5E',
      }}>
        {title}
      </h2>
    </div>
    {subtitle && (
      <p style={{ color: '#7B7BA8', fontSize: 14, marginLeft: 34 }}>{subtitle}</p>
    )}
  </div>
);

export default SectionHeader;
