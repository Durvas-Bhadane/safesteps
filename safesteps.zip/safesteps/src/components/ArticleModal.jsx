import React from 'react';
import { CATEGORIES } from '../data/data';

const ArticleModal = ({ article, onClose, onQuiz }) => {
  if (!article) return null;
  const cat = CATEGORIES.find(c => c.id === article.categoryId) || CATEGORIES[0];

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={e => e.stopPropagation()}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 20 }}>
          <div style={{
            width: 52, height: 52, borderRadius: 16, background: cat.bg,
            display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26,
          }}>
            {cat.icon}
          </div>
          <div>
            <div style={{ fontWeight: 800, fontSize: 20, color: '#2D2D5E' }}>{article.title}</div>
            <div style={{ fontSize: 13, color: '#7B7BA8' }}>By {article.author} · {article.readTime}</div>
          </div>
        </div>

        <p style={{ color: '#7B7BA8', lineHeight: 1.7, marginBottom: 20, fontSize: 15 }}>
          {article.content}
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24 }}>
          <div style={{ background: '#e6fdf8', borderRadius: 16, padding: 16 }}>
            <div style={{ fontWeight: 800, color: '#006654', marginBottom: 10 }}>✅ Do's</div>
            {article.dos.map((d, i) => (
              <div key={i} style={{ fontSize: 13, color: '#006654', marginBottom: 6, display: 'flex', gap: 6 }}>
                <span>•</span>{d}
              </div>
            ))}
          </div>
          <div style={{ background: '#fff0f3', borderRadius: 16, padding: 16 }}>
            <div style={{ fontWeight: 800, color: '#c0002a', marginBottom: 10 }}>❌ Don'ts</div>
            {article.donts.map((d, i) => (
              <div key={i} style={{ fontSize: 13, color: '#c0002a', marginBottom: 6, display: 'flex', gap: 6 }}>
                <span>•</span>{d}
              </div>
            ))}
          </div>
        </div>

        <div style={{ display: 'flex', gap: 10 }}>
          <button className="btn btn-primary" onClick={() => onQuiz(article.quizId)} style={{ flex: 1, justifyContent: 'center' }}>
            🎯 Take Quiz
          </button>
          <button className="btn btn-secondary" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
};

export default ArticleModal;
