import React from 'react';

const Sidebar = ({ links, activePage, onNavigate }) => (
  <div style={{
    width: 220, background: 'white', borderRight: '2px solid #f0efff',
    padding: '20px 12px', display: 'flex', flexDirection: 'column', gap: 4,
    minHeight: 'calc(100vh - 64px)', position: 'sticky', top: 64,
    boxShadow: '2px 0 16px rgba(108,99,255,0.04)',
  }}>
    {links.map(link => (
      <button
        key={link.id}
        className={`sidebar-link ${activePage === link.id ? 'active' : ''}`}
        onClick={() => onNavigate(link.id)}
      >
        <span style={{ fontSize: 20 }}>{link.icon}</span>
        <span>{link.label}</span>
      </button>
    ))}
  </div>
);

export default Sidebar;
